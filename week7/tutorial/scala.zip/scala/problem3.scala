package comp9313.lab7
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

object VotesStat {

  def Question2(textFile: DataFrame, spark: SparkSession) {
    import spark.implicits._
    val puPairDF = textFile.filter($"VoteTypeId" === "5").select("PostId", "UserId").distinct.withColumn("PostId", col("PostId").cast("int")).withColumn("UserId", col("UserId").cast("int"))
    val countsDF = puPairDF.groupBy("PostId").agg(collect_list("UserId") as "userList", count("PostId") as "count").filter($"count" > 10)
    val resDF = countsDF.select("PostId", "userList").withColumn("userList", sort_array($"userList")) 
    resDF.foreach(x => println(x.getInt(0)+"#"+x.getList(1)))
  }
  
  def Question1(textFile: DataFrame, spark: SparkSession) {
    import spark.implicits._
    val pvPairDF = textFile.select("VoteTypeId", "PostId").distinct
    val countsDF = pvPairDF.groupBy("VoteTypeId").count().toDF("VoteTypeId", "numPosts").orderBy(-$"numPosts")
    val res = countsDF.take(5)
    res.foreach(x => println(x.getString(0)+"\t"+x.getLong(1)))        
  }


  def main(args: Array[String]) {
    val inputFile = args(0)
    val outputFolder = args(1)
    val spark = SparkSession.builder.appName("VotesStat").getOrCreate()
    val textFile = spark.read.csv(inputFile).toDF("Id", "PostId", "VoteTypeId", "UserId", "CreationTime")
    
    Question1(textFile, spark)
    Question2(textFile, spark)
    spark.stop()
  }
}


