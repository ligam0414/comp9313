package comp9313.lab7
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object LetterCount {
  def main(args: Array[String]) {
    
    val inputFile = args(0)
    val outputFolder = args(1)
    val spark = SparkSession.builder.appName("LetterCount").getOrCreate()
    import spark.implicits._
    val textFile = spark.read.textFile(inputFile)
    
    val wordsDF = textFile.flatMap(_.split(" ")).toDF("word").withColumn("word", lower(col("word"))).filter(length(col("word")) >=1).filter(col("word").substr(0,1)<= 'z' && col("word").substr(0,1)>='a')

    val letterDF = wordsDF.withColumn("word", wordsDF.col("word").substr(0, 1)).toDF("letter")
    
    val countsDF = letterDF.groupBy("letter").count().orderBy("letter")

    countsDF.write.format("csv").save(outputFolder)
    spark.stop()
  }
}

