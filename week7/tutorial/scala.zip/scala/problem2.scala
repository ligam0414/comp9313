package comp9313.lab7
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object WordAverageLen {
  def main(args: Array[String]) {    
    val inputFile = args(0)
    val outputFolder = args(1)
    val spark = SparkSession.builder.appName("WordAverageLen").getOrCreate()
    import spark.implicits._
    val textFile = spark.read.textFile(inputFile)
    
    val wordsDF = textFile.flatMap(_.split("[\\s*$&#/\"'\\,.:;?!\\[\\](){}<>~\\-_]+")).toDF("word").withColumn("word", lower(col("word"))).filter(length(col("word")) >=1).filter(col("word").substr(0,1)<= 'z' && col("word").substr(0,1)>='a')

    val pairDF = wordsDF.select(wordsDF.col("word").substr(0, 1), length(wordsDF.col("word"))).toDF("letter", "length")
    
    val countsDF = pairDF.groupBy("letter").agg(count("letter").as("totalCount"), sum("length").as("totalLength"))
    
    val avgDF = countsDF.withColumn("ratio", $"totalLength"/$"totalCount").select("letter", "ratio").orderBy("letter")
    avgDF.write.format("csv").save(outputFolder)
    spark.stop()
  }
}
