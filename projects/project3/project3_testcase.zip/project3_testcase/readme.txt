Two more testcases for project 3.

Your program should return the result in a reasonable time. The efficiency and scalability of this project is very important and will be evaluated.

The tau value of the first test case is 0.4. 

The tau value of the second test case is 0.6. 